package com.learningtechjava.springsecurityexample;

import java.security.Principal;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@SpringBootApplication
public class SpringSecurityDemo1Application {
	
	@Bean
	UserDetailsService userDetailsService() {
		return new InMemoryUserDetailsManager();
	}
	
	@Bean
	InitializingBean initializer(UserDetailsManager manager) {
		return() -> {
			UserDetails user = User.withDefaultPasswordEncoder().username("maddy").password("123456").roles("USER").build();
			manager.createUser(user);
		};
	}
	
	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityDemo1Application.class, args);
	}

}

@Configuration
@EnableWebSecurity
class SecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		//super.configure(http);
		http.authorizeRequests().anyRequest().authenticated(); // authenticate all incoming request
		http.formLogin().loginPage("/login").permitAll();
		http.logout().logoutUrl("/logout").logoutSuccessUrl("/logout-success");
	}
}


@ControllerAdvice
class PrincipalControllerAdvice{
	
	@ModelAttribute("currentUser")
	Principal principal(Principal p) {
		return p;
	}
}

@Controller
class LoginControlle{
	
	@GetMapping("/")
	String index() {
		return "hidden";
	}
	
	@GetMapping("/login")
	String login() {
		return "login";
	}
	
	@GetMapping("/logout-success")
	String logout() {
		return "logout";
	}
	
}

