package com.learningtechjava.springsecurityexample;

import java.security.Principal;
import java.util.Collections;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SpringSecurityDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityDemo2Application.class, args);
	}

}

@Configuration
@EnableWebSecurity
class CustomSecurityConfiguration extends WebSecurityConfigurerAdapter{
	
	private final CustomAuthenticationProvider ap;
	
	public CustomSecurityConfiguration(CustomAuthenticationProvider ap) {
		// TODO Auto-generated constructor stub
		this.ap = ap;
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		//uper.configure(http);
		http.httpBasic();
		http.authorizeRequests().anyRequest().authenticated();
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		//super.configure(auth);
		auth.authenticationProvider(ap);
	}
}

@Component
class CustomAuthenticationProvider implements AuthenticationProvider {
	
	private final List<SimpleGrantedAuthority> authorities = Collections.singletonList
			(new SimpleGrantedAuthority("USER"));
	
	boolean isValid(String user, String pw) {
		return user.equals("madhvi") && pw.equals("123456");
	}
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		// TODO Auto-generated method stub
		String username = authentication.getName();
		String password = authentication.getCredentials().toString();
		if(isValid(username, password)) {
			return new UsernamePasswordAuthenticationToken(username, password, authorities);
		}
		throw new BadCredentialsException("could not authenticate using "+username);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		// TODO Auto-generated method stub
		return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
	}
	
}

@RestController
class GreetingRestController{
	
	@GetMapping("/greet")
	String greeting(Principal principal) { // principal injected by spring security
		return "hello, "+ principal.getName();
	}
	
}
