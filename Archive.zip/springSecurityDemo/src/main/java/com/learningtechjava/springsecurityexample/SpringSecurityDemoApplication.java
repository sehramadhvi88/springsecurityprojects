package com.learningtechjava.springsecurityexample;

import java.security.Principal;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SpringSecurityDemoApplication {

	@Bean
	UserDetailsService userDetailsService() {
		return new InMemoryUserDetailsManager();
	}
	
	@Bean
	InitializingBean initializer(UserDetailsManager manager) {
		return() -> {
			UserDetails user = User.withDefaultPasswordEncoder().username("madhvi").password("123456").roles("USER").build();
			manager.createUser(user);
		};
	}
	
	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityDemoApplication.class, args);
	}

}

@RestController
class GreetingRestController{
	
	@GetMapping("/greet")
	String greeting(Principal principal) { // principal injected by spring security
		return "hello, "+ principal.getName();
	}
	/**
	 *  Principal 
	 *  UserDetailsService
	 *  Authentication Object
	 *  Authentication Manager
	 *  Authentication Provider
	 */
}

@Configuration
@EnableWebSecurity
class SecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		super.configure(http);
		http.httpBasic();
		http.authorizeRequests().anyRequest().authenticated(); // authenticate all incoming request
	}
}

/**
 *  spring security take some incoming request and turn into authentication object and passes into someething 
 * 
 */
